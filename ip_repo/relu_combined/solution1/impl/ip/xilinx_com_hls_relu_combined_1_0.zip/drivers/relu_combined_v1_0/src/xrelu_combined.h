// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XRELU_COMBINED_H
#define XRELU_COMBINED_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xrelu_combined_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Ctrl_BaseAddress;
} XRelu_combined_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XRelu_combined;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XRelu_combined_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XRelu_combined_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XRelu_combined_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XRelu_combined_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XRelu_combined_Initialize(XRelu_combined *InstancePtr, u16 DeviceId);
XRelu_combined_Config* XRelu_combined_LookupConfig(u16 DeviceId);
int XRelu_combined_CfgInitialize(XRelu_combined *InstancePtr, XRelu_combined_Config *ConfigPtr);
#else
int XRelu_combined_Initialize(XRelu_combined *InstancePtr, const char* InstanceName);
int XRelu_combined_Release(XRelu_combined *InstancePtr);
#endif

void XRelu_combined_Start(XRelu_combined *InstancePtr);
u32 XRelu_combined_IsDone(XRelu_combined *InstancePtr);
u32 XRelu_combined_IsIdle(XRelu_combined *InstancePtr);
u32 XRelu_combined_IsReady(XRelu_combined *InstancePtr);
void XRelu_combined_EnableAutoRestart(XRelu_combined *InstancePtr);
void XRelu_combined_DisableAutoRestart(XRelu_combined *InstancePtr);

void XRelu_combined_Set_dim(XRelu_combined *InstancePtr, u32 Data);
u32 XRelu_combined_Get_dim(XRelu_combined *InstancePtr);
void XRelu_combined_Set_fwprop(XRelu_combined *InstancePtr, u32 Data);
u32 XRelu_combined_Get_fwprop(XRelu_combined *InstancePtr);

void XRelu_combined_InterruptGlobalEnable(XRelu_combined *InstancePtr);
void XRelu_combined_InterruptGlobalDisable(XRelu_combined *InstancePtr);
void XRelu_combined_InterruptEnable(XRelu_combined *InstancePtr, u32 Mask);
void XRelu_combined_InterruptDisable(XRelu_combined *InstancePtr, u32 Mask);
void XRelu_combined_InterruptClear(XRelu_combined *InstancePtr, u32 Mask);
u32 XRelu_combined_InterruptGetEnabled(XRelu_combined *InstancePtr);
u32 XRelu_combined_InterruptGetStatus(XRelu_combined *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
